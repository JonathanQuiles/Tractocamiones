<?php

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tractocamiones";
$tbl_name = "caracteristicas";
    

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
/*echo "Connected successfully";*/



$sel = mysqli_query($conn,"select * from $tbl_name");
$data = array();

while ($row = mysqli_fetch_array($sel)) {
 $data[] = array("id"=>$row['id'], "modelo"=>$row['modelo'], "precio"=>$row['precio'], "age"=>$row['age'], "transmicion"=>$row['transmicion'], "descripcion"=>$row['descripcion'], "marca"=>$row['marca'], "tipo"=>$row['tipo'], "motor"=>$row['motor']);
}
echo json_encode($data);


?>
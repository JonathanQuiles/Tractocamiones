<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tractocamiones";
$tbl_name = "caracteristicas";
    

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
    

    
 $data = json_decode(file_get_contents("php://input"));  
 if(count($data) > 0)  
 {  
      $modelo = mysqli_real_escape_string($conn, $data->modelo);       
      $precio = mysqli_real_escape_string($conn, $data->precio);  
      $transmicion = mysqli_real_escape_string($conn, $data->transmicion);  
      $motor = mysqli_real_escape_string($conn, $data->motor);  
      $age = mysqli_real_escape_string($conn, $data->age);  
      $marca = mysqli_real_escape_string($conn, $data->marca);  
      $tipo = mysqli_real_escape_string($conn, $data->tipo);  
      $descripcion = mysqli_real_escape_string($conn, $data->descripcion); 
     
      $query = "INSERT INTO $tbl_name (modelo, precio, transmicion, motor, age, marca, tipo, descripcion) VALUES ('$modelo', '$precio', '$transmicion', '$motor', '$age', '$marca', '$tipo', '$descripcion')";  
      if(mysqli_query($conn, $query))  
      {  
           echo "Data Inserted...";  
      }  
      else  
      {  
           echo 'Error';  
      }  
 }  


$conn->close();    

?>
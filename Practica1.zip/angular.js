// Creación del módulo
var app = angular.module("myApp", []);



app.directive("fileInput", function($parse){
    return{
        link: function($scope, element, attrs){
            element.on("change", function(event){
                var files = event.target.files;
                $parse(attrs.fileInput).assign($scope, element[0].files);
                $scope.$apply();
            });
        }
    }
});



app.controller("myCtrl", function($scope, $http){

/*
    $scope.uploadImage = function(){
        
    var form_data = new FormData();
    angular.forEach($scope.files, function(file){
        console.log(file);
        
        form_data.append('file', file);
    }); 
     
            
    $http.post('image_upload.php', form_data,
    {
        transformRequest: angular.identity,
        headers: {'Content-Type': undefined,'Process-Data': false}
    })
    .then(function(response){
        alert(response);
        $scope. show_images();
    });
}



    $scope.show_images = function(){
        $http.get("show_images.php").then(function(response){
            
            $scope.images = response.data;
            console.log($scope.images);

        });
    }

*/
 
    
    $scope.Agregar = function(){  
        
        $scope.datos = {
             'modelo':$scope.modelo
        }; 
        
        var form_data = new FormData();        
        angular.forEach($scope.files, function(file){
            console.log(file);

            form_data.append('file', file);
        }); 
        
        
        console.log($scope.datos);
        
        
        $http.post('agregar.php', ($scope.datos, form_data),
        {   
            
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined,'Process-Data': false}
        })
        .then(function(response){
                    
            alert('Dato insertado correctamente 1.0');
            $scope.show_images();
            console.log('Dato insertado correctamente 2.0');
        });

        
    
        $scope.show_images = function(){
        $http.get("show_images.php").then(function(response){
            
            $scope.images = response.data;
            console.log($scope.images);

        });
        }
        
        
        

        /*
        $http.post("agregar.php", ($scope.datos, form_data).then(function(response){
        
            console.log('Dato insertado correctamente');
        });  
        */
    };
  
    
    
});

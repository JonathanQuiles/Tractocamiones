<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tractocamiones";
    

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
/*echo "Connected successfully";*/
    

$output = [];
$query = "SELECT * FROM images ORDER BY id DESC";
$result = mysqli_query($conn, $query);/*or die("database error:". mysqli_error($conn));*/


while($row = mysqli_fetch_array($result)) {
 
    $output[] = $row;
}

echo json_encode($output);

$conn->close();    

?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tractocamiones";
$tbl_name = "images";
    

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
    




 $data = json_decode(file_get_contents("php://input"));

echo '<br> hola <br>';

echo '';
if((!empty($_FILES)) && (count($data) > 0 ))  
 {  
    
      $modelo = mysqli_real_escape_string($conn, $data->modelo); 
        
      $path = 'upload/' . $_FILES['file']['name'];
      $filename = $_FILES['file']['name'];

      if(move_uploaded_file($_FILES['file']['tmp_name'], $path))  
      {  
           $insert_sql = "INSERT INTO $tbl_name (file_name, modelo) VALUES ('$filename', '$modelo')";
           if(mysqli_query($conn, $insert_sql))  
           {  
                echo 'File Uploaded';  
           }  
           else  
           {  
                echo 'File Uploaded But not Saved';  
           }  
      }  
 }  
 else  
 {  
      echo 'Some Error';  
 } 

  /*
 if(count($data) > 0)  
 {  
      $modelo = mysqli_real_escape_string($conn, $data->modelo);       
     
      $query = "INSERT INTO $tbl_name (modelo) VALUES ('$modelo')";  
      if(mysqli_query($conn, $query))  
      {  
           echo "Data Inserted...";  
      }  
      else  
      {  
           echo 'Error';  
      }  
 }  

*/













/*   
 $data = json_decode(file_get_contents("php://input"));  
 if(count($data) > 0)  
 {  
      $modelo = mysqli_real_escape_string($conn, $data->modelo);       
     
      $query = "INSERT INTO $tbl_name (modelo) VALUES ('$modelo')";  
      if(mysqli_query($conn, $query))  
      {  
           echo "Data Inserted...";  
      }  
      else  
      {  
           echo 'Error';  
      }  
 }  
*/

$conn->close();    

?>
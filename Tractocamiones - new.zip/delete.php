<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tractocamiones";
$tbl_name = "caracteristicas";
    

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
    

 $data = json_decode(file_get_contents("php://input"));  

 if(count($data) > 0)  
 {  
      $id = $data->id;  
      $sql = "DELETE FROM $tbl_name WHERE id='$id'"; 
      
      $resultado = $conn->query($sql);
      if($resultado)  
      {  
           echo 'Data Deleted';  
      }  
      else  
      {  
           echo 'Error';  
      }  
 }  



$conn->close();    

?>
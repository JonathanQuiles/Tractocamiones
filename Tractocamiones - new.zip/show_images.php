<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tractocamiones";
$tbl_name = "caracteristicas";
    

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
/*echo "Connected successfully";*/
    






$output = [];
$query = "SELECT file_name FROM images ORDER BY id DESC";
$result = mysqli_query($conn, $query);


while($row = mysqli_fetch_array($result)) {
 
    $output[] = $row;
}

echo json_encode($output);

$conn->close();

?>

